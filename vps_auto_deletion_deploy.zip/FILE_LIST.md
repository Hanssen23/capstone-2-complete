# FILES INCLUDED IN THIS DEPLOYMENT 
 
## New Files: 
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Console\Commands\ProcessInactiveMemberDeletion.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Http\Controllers\AutoDeletionController.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Http\Controllers\MemberReactivationController.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Http\Middleware\TrackMemberActivity.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Models\AutoDeletionSettings.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Models\MemberDeletionLog.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Notifications\MemberDeletionWarning.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\app\Notifications\MemberFinalDeletionWarning.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\database\migrations\2025_01_07_000002_add_activity_tracking_to_members_table.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\database\migrations\2025_01_07_000003_create_member_deletion_logs_table.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\database\migrations\2025_01_07_000004_create_auto_deletion_settings_table.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\resources\views\admin\auto-deletion\index.blade.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\resources\views\admin\auto-deletion\logs.blade.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\resources\views\member\reactivation\form.blade.php
C:\Users\hanss\Documents\silencio-gym-mms-main\auto_deletion_deployment\resources\views\member\reactivation\success.blade.php
 
## Updated Files: 
app\Models\Member.php 
app\Http\Controllers\AuthController.php 
app\Http\Controllers\RfidController.php 
routes\web.php 
bootstrap\app.php 
app\Console\Kernel.php 
